(function () {
  "use strict";
  var collapsedOnce = false;

  function isPhone() {
    return window.innerWidth <= 1100 || window.innerHeight <= 620;
  }

  function collapseForPhone() {
    if (collapsedOnce || !isPhone()) return;
    collapsedOnce = true;
    var btn = document.getElementById("ledgerCollapse");
    if (btn) btn.click();
  }

  function init() {
    setTimeout(collapseForPhone, 800);
    setTimeout(collapseForPhone, 1600);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
