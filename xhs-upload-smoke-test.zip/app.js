document.getElementById("btn").addEventListener("click", function () {
  document.getElementById("out").textContent = "按钮点击成功 · " + new Date().toLocaleTimeString();
});
